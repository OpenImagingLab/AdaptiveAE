# AdaptiveAE GitHub Pages 部署指南

## 概述
这是AdaptiveAE项目的GitHub Pages网站，基于师兄的AdaptiveISP模板制作。包含了论文的主要信息、摘要、方法展示和视频演示。

## 文件结构
```
AdaptiveAE-website/
├── docs/
│   ├── index.html          # 主页面
│   └── static/
│       ├── css/            # 样式文件
│       ├── js/             # JavaScript文件
│       ├── images/         # 图片文件
│       │   ├── teaser.pdf  # 论文主图
│       │   └── pipeline.pdf # 方法流程图
│       └── videos/
│           └── video.mp4   # 视频演示
└── README.md              # 部署指南
```

## GitHub Pages 部署步骤

### 1. 创建GitHub仓库
1. 登录到你的GitHub账户
2. 点击右上角的 "+" 号，选择 "New repository"
3. 仓库名称可以命名为：`AdaptiveAE` 或 `AdaptiveAE-website`
4. 确保仓库是 **Public**（私有仓库需要付费才能使用GitHub Pages）
5. 点击 "Create repository"

### 2. 上传网站文件
有两种方法上传文件：

#### 方法一：使用GitHub网页界面
1. 在新创建的仓库页面，点击 "uploading an existing file"
2. 将整个 `AdaptiveAE-website` 文件夹中的所有内容拖拽到页面上
3. 在提交信息中写入："Initial website setup"
4. 点击 "Commit changes"

#### 方法二：使用Git命令行（推荐）
```bash
# 在 AdaptiveAE-website 文件夹中打开终端
cd AdaptiveAE-website

# 初始化Git仓库
git init

# 添加所有文件
git add .

# 提交文件
git commit -m "Initial website setup"

# 添加远程仓库（替换YOUR_USERNAME和YOUR_REPO_NAME）
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git

# 推送到GitHub
git branch -M main
git push -u origin main
```

### 3. 启用GitHub Pages
1. 在GitHub仓库页面，点击 "Settings" 标签
2. 在左侧菜单中找到 "Pages"
3. 在 "Source" 部分，选择 "Deploy from a branch"
4. 在 "Branch" 下拉菜单中选择 "main"
5. 在文件夹选择中选择 "/docs"（因为我们的网站文件在docs文件夹中）
6. 点击 "Save"

### 4. 访问网站
1. GitHub会自动部署网站，通常需要几分钟时间
2. 部署完成后，你的网站将可以通过以下地址访问：
   ```
   https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/
   ```
3. GitHub会在Settings页面的Pages部分显示你的网站地址

## 重要注意事项

### 关于图片格式
- 网站中使用了PDF格式的图片（teaser.pdf, pipeline.pdf）
- 如果PDF图片无法在网页中正常显示，建议将其转换为PNG或JPG格式
- 转换后需要在 `index.html` 中更新对应的文件路径

### 更新内容
如果你需要更新网站内容：
1. 修改本地文件
2. 使用git提交并推送更改：
   ```bash
   git add .
   git commit -m "Update website content"
   git push
   ```
3. GitHub会自动重新部署网站

### 自定义域名（可选）
如果你有自己的域名，可以在Settings -> Pages中设置Custom domain。

### 故障排除
1. **网站无法访问**：检查GitHub Pages是否已启用，并确保选择了正确的分支和文件夹
2. **图片不显示**：检查图片路径是否正确，确保所有文件都已上传
3. **样式不正常**：检查CSS文件路径，确保static文件夹结构正确

## 后续优化建议
1. 将PDF图片转换为更适合网页的格式（PNG/JPG）
2. 添加论文的arXiv链接和GitHub代码链接
3. 优化视频文件大小以提高加载速度
4. 添加更多实验结果展示

## 联系方式
如果部署过程中遇到问题，可以：
1. 检查GitHub Pages官方文档
2. 查看仓库的Actions标签页了解部署状态
3. 检查浏览器开发者工具的控制台是否有错误信息